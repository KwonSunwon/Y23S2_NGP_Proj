#pragma once
#include "stdafx.h"

struct BUFFER
{
	GLuint vao, vbo[2];
	GLuint EBO;
};