#include "physics.h"

Physics::Physics() { };

Physics::~Physics()
{
};