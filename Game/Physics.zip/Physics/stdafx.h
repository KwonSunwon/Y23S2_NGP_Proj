#pragma once
#ifndef __STDAFX_H__
#define __STDAFX_H__
#define _CRT_SECURE_NO_WARNINGS

#include "../Client/api/OpenGL/glew.h"
#include "../Client/api/OpenGL/freeglut.h"
#include "../Client/api/OpenGL/freeglut_ext.h"
#include "../Client/api/OpenGL/glm/glm.hpp"
#include "../Client/api/OpenGL/glm/ext.hpp"
#include "../Client/api/OpenGL/glm/gtc/matrix_transform.hpp"

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <random>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <math.h>
#include <chrono>

#define MAX_SPEED 0.02f
#define ACCELERATION 0.002f

#define NUM_OF_PLAYER 3

using namespace std;

#endif